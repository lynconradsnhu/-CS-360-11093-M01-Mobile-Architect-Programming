package com.example.cs360project2.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper  {

    public DatabaseHelper(Context context) {
        super(context, "events.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // create the users table
        String createUsersTable = "CREATE TABLE users ( id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE, password TEXT, phoneNumber TEXT )";
        db.execSQL(createUsersTable);

        // create the events table
        String createEventsTable = "CREATE TABLE events ( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, category TEXT, date TEXT, duration TEXT )";
        db.execSQL(createEventsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop tables on update if they already exist, then recreate (data loss)
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS events");

        onCreate(db);
    }

    public boolean createUser(String username, String password, String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        values.put("phoneNumber", phoneNumber);

        long result = db.insert("users", null, values);

        return result != -1;
    }

    public User getUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String []{ username, password });

        User user = new User(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3));

        cursor.close();

        return user;
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String []{ username, password });

        boolean exists = cursor.getCount() > 0;

        cursor.close();

        return exists;
    }

    public boolean addEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", event.getName());
        values.put("description", event.getDescription());
        values.put("category", event.getCategory());
        values.put("date", event.getDate());
        values.put("duration", event.getDuration());

        long result = db.insert("events", null, values);

        return result != -1;
    }

    public ArrayList<Event> getEvents(String startDate, String endDate) {
        ArrayList<Event> events = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor;

        boolean hasStartDate = startDate != null && !startDate.isEmpty();
        boolean hasEndDate = endDate != null && !endDate.isEmpty();

        if (!hasStartDate && !hasEndDate) {
            cursor = db.rawQuery("SELECT * FROM events ORDER BY date ASC", null);
        }
        else if (!hasStartDate) {
            cursor = db.rawQuery("SELECT * FROM events WHERE date <= ? ORDER BY date ASC", new String[]{endDate});
        }
        else if (!hasEndDate) {
            cursor = db.rawQuery("SELECT * FROM events WHERE date >= ? ORDER BY date ASC", new String[]{startDate});
        }
        else {
            cursor = db.rawQuery("SELECT * FROM events WHERE date >= ? AND date <= ? ORDER BY date ASC", new String[]{startDate, endDate});
        }

        if (cursor.moveToFirst()) {
            do {
                Event event = new Event(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4),
                        cursor.getString(5)

                );

                events.add(event);

            } while (cursor.moveToNext());
        }

        cursor.close();

        return events;
    }

    public boolean updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", event.getName());
        values.put("description", event.getDescription());
        values.put("category", event.getCategory());
        values.put("date", event.getDate());
        values.put("duration", event.getDuration());

        long rows = db.update("events", values, "id=?", new String[]{String.valueOf(event.getId())});

        return rows > 0;
    }

    public boolean deleteEvent(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();

        long rows = db.delete("events", "id=?", new String[]{String.valueOf(id)});

        return rows > 0;
    }
}
