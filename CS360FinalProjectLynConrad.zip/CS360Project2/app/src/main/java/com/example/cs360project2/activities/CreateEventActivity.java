package com.example.cs360project2.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.cs360project2.data.DatabaseHelper;
import com.example.cs360project2.data.Event;
import com.example.cs360project2.notifications.NotificationScheduler;
import com.example.cs360project2.R;

public class CreateEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        EditText newNameInput = findViewById(R.id.editNameText);
        EditText newDescriptionInput = findViewById(R.id.editDescriptionText);
        EditText newCategoryInput = findViewById(R.id.editCategoryText);
        EditText newDateInput = findViewById(R.id.editDateText);
        EditText newDurationInput = findViewById(R.id.editDurationText);
        Button submitButton = findViewById(R.id.createNewEventButton);
        Button backButton = findViewById(R.id.backButton);

        submitButton.setOnClickListener(v -> {
            String name = newNameInput.getText().toString().trim();
            String description = newDescriptionInput.getText().toString().trim();
            String category = newCategoryInput.getText().toString().trim();
            String date = newDateInput.getText().toString().trim();
            String duration = newDurationInput.getText().toString().trim();

            // only the name and date are required fields
            if (name.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please enter a name and date", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseHelper db = new DatabaseHelper(this);
            Event event = new Event(db.getEvents("", "").size() + 1, name, description, category, date, duration);
            boolean success = db.addEvent(event);

            if (success) {
                Toast.makeText(this, "Event created successfully", Toast.LENGTH_SHORT).show();

                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    NotificationScheduler.scheduleEventNotification(this, event);
                }
            }
            else {
                Toast.makeText(this, "Event could not be created", Toast.LENGTH_SHORT).show();
            }

            finish(); // return to LoginActivity
        });

        backButton.setOnClickListener(v -> finish());
    }
}
