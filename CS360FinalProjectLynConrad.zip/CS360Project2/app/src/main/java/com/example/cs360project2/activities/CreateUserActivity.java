package com.example.cs360project2.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360project2.data.DatabaseHelper;
import com.example.cs360project2.R;

public class CreateUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        EditText newUsernameInput = findViewById(R.id.editUsernameText);
        EditText newPasswordInput = findViewById(R.id.editPasswordText);
        EditText newPhoneNumberInput = findViewById(R.id.editPhoneNumberText);
        Button submitButton = findViewById(R.id.createNewUserButton);
        Button backButton = findViewById(R.id.backButton);

        submitButton.setOnClickListener(v -> {
            String username = newUsernameInput.getText().toString().trim();
            String password = newPasswordInput.getText().toString().trim();
            String phoneNumber = newPhoneNumberInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseHelper db = new DatabaseHelper(this);
            boolean success = db.createUser(username, password, phoneNumber);
            if (success) {
                Toast.makeText(this, "User created successfully", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            }

            finish(); // return to LoginActivity
        });

        backButton.setOnClickListener(v -> finish());
    }
}

