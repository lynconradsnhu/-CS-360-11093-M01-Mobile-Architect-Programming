package com.example.cs360project2.activities;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360project2.data.DatabaseHelper;
import com.example.cs360project2.R;
import com.example.cs360project2.data.User;
import com.example.cs360project2.data.UserSession;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // instantiate variables
        EditText usernameInput = findViewById(R.id.editUsernameText);
        EditText passwordInput = findViewById(R.id.editPasswordText);
        Button loginButton = findViewById(R.id.loginButton);
        Button createUserButton = findViewById(R.id.createNewUserButton);

        // listen for login button click
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // check against database
            DatabaseHelper db = new DatabaseHelper(this);
            if (db.validateUser(username, password)) {
                User user = db.getUser(username, password);
                UserSession.login(user.getId(), username, user.getPhoneNumber());
                Intent intent = new Intent(this, EventsActivity.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }

        });

        // listen for create user button click
        createUserButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateUserActivity.class);
            startActivity(intent);
        });

        createNotificationChannel();
    }

    private void createNotificationChannel() {

        NotificationChannel channel = new NotificationChannel("event_reminders", "Event Reminders", NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("Notifications for upcoming events");

        NotificationManager manager = getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
    }
}