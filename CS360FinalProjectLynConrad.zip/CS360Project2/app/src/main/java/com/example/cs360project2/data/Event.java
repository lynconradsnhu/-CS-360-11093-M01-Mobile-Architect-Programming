package com.example.cs360project2.data;

public class Event {
    private int id;
    private String name;
    private String description;
    private String category;
    private String date;
    private String duration;

    public Event(int id, String name, String description, String category, String date, String duration) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.date = date;
        this.duration = duration;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getCategory() { return category; }
    public String getDate() { return date; }
    public String getDuration() { return duration; }
}