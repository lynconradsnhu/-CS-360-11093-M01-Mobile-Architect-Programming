package com.example.cs360project2.data;

public class UserSession {
    private static int currentUserId = -1;
    private static String userName = null;
    private static String phoneNumber = null;

    public static void login(int userId, String userName, String phoneNumber) {
        currentUserId = userId;
        UserSession.userName = userName;
        UserSession.phoneNumber = phoneNumber;
    }

    public static void logout() {
        currentUserId = -1;
        userName = null;
        phoneNumber = null;
    }

    public static int getCurrentUserId() {
        return currentUserId;
    }

    public static String getUserName() {
        return userName;
    }

    public static String getPhoneNumber() {
        return phoneNumber;
    }
}
