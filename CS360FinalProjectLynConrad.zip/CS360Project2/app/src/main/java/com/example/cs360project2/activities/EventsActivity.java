package com.example.cs360project2.activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs360project2.data.DatabaseHelper;
import com.example.cs360project2.data.Event;
import com.example.cs360project2.adapters.EventsAdapter;
import com.example.cs360project2.R;

import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public class EventsActivity extends AppCompatActivity {

    private EventsAdapter eventsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        RecyclerView eventsRecyclerView = findViewById(R.id.eventsRecyclerView);
        EditText startDateFilter = findViewById(R.id.startDateFilter);
        EditText endDateFilter = findViewById(R.id.endDateFilter);
        Button createEventButton = findViewById(R.id.createEventButton);

        eventsRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        DatabaseHelper db = new DatabaseHelper(this);
        AtomicReference<List<Event>> events = new AtomicReference<>(db.getEvents(null, null));
        eventsAdapter = new EventsAdapter(events.get(), this);
        eventsRecyclerView.setAdapter(eventsAdapter);

        findViewById(R.id.filterButton).setOnClickListener(v -> {
            String start = startDateFilter.getText().toString().trim();
            String end = endDateFilter.getText().toString().trim();

            events.set(db.getEvents(start, end));
            eventsAdapter.updatedEvents(events.get());
        });

        createEventButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, CreateEventActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        DatabaseHelper db = new DatabaseHelper(this);
        List<Event> events = db.getEvents(null, null);
        eventsAdapter.updatedEvents(events);
    }
}
