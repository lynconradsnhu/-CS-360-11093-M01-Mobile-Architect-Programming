package com.example.cs360project2.notifications;


import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.annotation.RequiresPermission;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.example.cs360project2.R;

public class EventNotificationReceiver extends BroadcastReceiver {

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    @Override
    public void onReceive(Context context, Intent intent) {

        String eventName = intent.getStringExtra("event_name");
        assert eventName != null;
        createNotification(context, eventName);

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(intent.getStringExtra("phone_number"), null, eventName + " is today.", null, null);
        }
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    private void createNotification(Context context, String eventName) {

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(context, "event_reminders")
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setContentTitle("Event Reminder")
                        .setContentText(eventName + " is today.")
                        .setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setAutoCancel(true);

        NotificationManagerCompat manager = NotificationManagerCompat.from(context);

        manager.notify(eventName.hashCode(), builder.build());
    }
}