package com.example.cs360project2.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360project2.data.DatabaseHelper;
import com.example.cs360project2.data.Event;
import com.example.cs360project2.notifications.NotificationScheduler;
import com.example.cs360project2.R;

public class ModifyEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        EditText editNameInput = findViewById(R.id.editNameText);
        EditText editDescriptionInput = findViewById(R.id.editDescriptionText);
        EditText editCategoryInput = findViewById(R.id.editCategoryText);
        EditText editDateInput = findViewById(R.id.editDateText);
        EditText editDurationInput = findViewById(R.id.editDurationText);
        Button submitButton = findViewById(R.id.createNewEventButton);
        Button backButton = findViewById(R.id.backButton);

        submitButton.setOnClickListener(v -> {
            String name = editNameInput.getText().toString().trim();
            String description = editDescriptionInput.getText().toString().trim();
            String category = editCategoryInput.getText().toString().trim();
            String date = editDateInput.getText().toString().trim();
            String duration = editDurationInput.getText().toString().trim();

            // only the name and date are required fields
            if (name.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "Please enter a name and date", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseHelper db = new DatabaseHelper(this);
            Event event = new Event(db.getEvents("", "").size() + 1, name, description, category, date, duration);
            boolean success = db.updateEvent(event);
            if (success) {
                Toast.makeText(this, "Event updated successfully", Toast.LENGTH_SHORT).show();

                NotificationScheduler.cancelNotification(this, event.getId());
                NotificationScheduler.scheduleEventNotification(this, event);
            }
            else {
                Toast.makeText(this, "Unable to update event", Toast.LENGTH_SHORT).show();
            }

            finish(); // return to LoginActivity
        });

        backButton.setOnClickListener(v -> finish());
    }
}
