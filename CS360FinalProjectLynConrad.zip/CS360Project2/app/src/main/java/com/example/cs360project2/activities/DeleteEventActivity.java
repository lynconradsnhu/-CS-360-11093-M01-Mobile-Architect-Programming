package com.example.cs360project2.activities;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cs360project2.data.DatabaseHelper;
import com.example.cs360project2.notifications.NotificationScheduler;
import com.example.cs360project2.R;

public class DeleteEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_event);

        Button submitButton = findViewById(R.id.deleteEventButton);
        Button backButton = findViewById(R.id.backButton);

        submitButton.setOnClickListener(v -> {

            DatabaseHelper db = new DatabaseHelper(this);
            db.deleteEvent(v.getId());

            Toast.makeText(this, "User deleted successfully", Toast.LENGTH_SHORT).show();
            NotificationScheduler.cancelNotification(this, v.getId());

            // return to LoginActivity
            finish();
        });

        backButton.setOnClickListener(v -> finish());
    }
}
