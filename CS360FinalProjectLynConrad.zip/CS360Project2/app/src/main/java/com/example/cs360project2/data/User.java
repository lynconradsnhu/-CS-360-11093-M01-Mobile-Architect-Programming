package com.example.cs360project2.data;

public class User {
    private int id;
    private String username;
    private String password;
    private String phoneNumber;

    public User(int id, String username, String password, String phoneNumber) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    public int getId() {
        return id;
    }

    public String getUserName() {
        return username;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
}
