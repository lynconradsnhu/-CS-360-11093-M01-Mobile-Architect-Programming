package com.example.cs360project2.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cs360project2.data.DatabaseHelper;
import com.example.cs360project2.data.Event;
import com.example.cs360project2.adapters.NotificationsAdapter;
import com.example.cs360project2.R;

import java.time.LocalDate;
import java.util.List;

public class NotificationsActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    TextView permissionStatusText;
    Button requestPermissionButton;
    Button denyPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        permissionStatusText = findViewById(R.id.permissionStatusText);
        requestPermissionButton = findViewById(R.id.requestPermissionButton);
        denyPermissionButton = findViewById(R.id.denyPermissionButton);
        Button backButton = findViewById(R.id.backButton);
        RecyclerView todaysNotificationsRecyclerView = findViewById(R.id.todaysNotificationsRecyclerView);

        // Load today's events
        todaysNotificationsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        DatabaseHelper db = new DatabaseHelper(this);
        List<Event> todaysEvents = db.getEvents(LocalDate.now().toString(), LocalDate.now().toString());
        NotificationsAdapter notificationsAdapter = new NotificationsAdapter(todaysEvents);
        todaysNotificationsRecyclerView.setAdapter(notificationsAdapter);

        checkPermissionStatus();

        requestPermissionButton.setOnClickListener(v -> requestSMSPermission());

        denyPermissionButton.setOnClickListener(v -> denySMSPermission());

        backButton.setOnClickListener(v -> finish());
    }

    private void checkPermissionStatus() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            permissionStatusText.setText(R.string.sms_permission_granted);
            requestPermissionButton.setVisibility(View.GONE);
            denyPermissionButton.setVisibility(View.VISIBLE);
        }
        else {
            permissionStatusText.setText(R.string.sms_permission_not_granted);
            requestPermissionButton.setVisibility(View.VISIBLE);
            denyPermissionButton.setVisibility(View.GONE);
        }
    }

    private void requestSMSPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    private void denySMSPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // this method automatically kills the app to safely revoke the permission
            this.revokeSelfPermissionOnKill(Manifest.permission.SEND_SMS);
            Toast.makeText(this, "SMS Permission Revoked. Restarting App...", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Unable to Revoke SMS Permission", Toast.LENGTH_SHORT).show();
        }

        // Update UI to reflect denial
        denyPermissionButton.setVisibility(View.GONE);
        requestPermissionButton.setVisibility(View.VISIBLE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantedResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantedResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantedResults.length > 0 && grantedResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted!", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }

        checkPermissionStatus();
    }
}
