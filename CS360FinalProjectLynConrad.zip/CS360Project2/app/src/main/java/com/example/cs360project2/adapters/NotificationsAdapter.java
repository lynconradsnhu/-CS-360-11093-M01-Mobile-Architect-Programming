package com.example.cs360project2.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import com.example.cs360project2.data.Event;
import com.example.cs360project2.R;

public class NotificationsAdapter extends RecyclerView.Adapter<NotificationsAdapter.NotificationViewHolder> {

    private final List<Event> todaysEvents;

    public NotificationsAdapter(List<Event> todaysEvents) {
        this.todaysEvents = todaysEvents;
    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_notification_row, parent, false);
        return new NotificationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        Event event = todaysEvents.get(position);
        holder.eventName.setText(event.getName());
        holder.eventDate.setText(event.getDate());
    }

    @Override
    public int getItemCount() {
        return todaysEvents.size();
    }

    static class NotificationViewHolder extends RecyclerView.ViewHolder {

        TextView eventName;
        TextView eventDate;

        public NotificationViewHolder(@NonNull View itemView) {
            super(itemView);
            eventName = itemView.findViewById(R.id.notificationEventName);
            eventDate = itemView.findViewById(R.id.notificationEventDate);
        }
    }
}